package com.example.ecommerce.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.example.ecommerce.utils.CascadeSave;

import lombok.Data;

@Document
@Data
public class CustomerAccount {
	
	@Id
	private String caId;
	private String customerName;
	@Indexed(unique=true)
	private String customerPhno;
	@Indexed(unique=true)
	private String customerEmail;
	@CascadeSave
	private List<Address> address;

}
