package com.example.ecommerce.model;

import lombok.Data;

@Data
public class Address {
	
	private String street;
	private String city;
	private String pincode;
	private String State;
	private String Country;

}
