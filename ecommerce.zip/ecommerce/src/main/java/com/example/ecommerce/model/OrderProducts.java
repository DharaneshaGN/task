package com.example.ecommerce.model;

import lombok.Data;

@Data
public class OrderProducts {
	
	private String pid;
	private int Qty;

}
