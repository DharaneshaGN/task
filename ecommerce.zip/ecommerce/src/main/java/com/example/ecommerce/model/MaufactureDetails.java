package com.example.ecommerce.model;

public class MaufactureDetails {
	
	private String name;
	private String modelNo;
	private String companyName;
}
