package com.example.ecommerce.model;

import lombok.Data;

@Data
public class PaymentDetails {
	
	private String paymentMode;
	private double amount;
	private String transctionId;

}
