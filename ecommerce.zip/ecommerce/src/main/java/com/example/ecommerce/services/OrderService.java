package com.example.ecommerce.services;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ecommerce.model.OrderProducts;
import com.example.ecommerce.model.Orders;
import com.example.ecommerce.model.Products;
import com.example.ecommerce.repository.OrderRepo;
import com.example.ecommerce.repository.ProductsRepo;

@Service
public class OrderService {
	
	@Autowired
	private OrderRepo orderRepo;
	
	@Autowired
	private ProductsRepo productsRepo;

	public Map<String, Object> PlaceOrder(String pid, int qty, String cid) {
		Map<String, Object> response = new HashMap<String, Object>();
		Products quantity=productsRepo.findByProductId(pid);
		if(quantity.getQuantity()>=qty){
			
			OrderProducts orderProducts = new OrderProducts();
			orderProducts.setPid(pid);
			orderProducts.setQty(qty);
			
			Orders orders = new Orders();
			orders.setCaId(cid);
			orders.setOrderProducts(orderProducts);
			orders=orderRepo.save(orders);
			int remainingQty=quantity.getQuantity()-qty;
			quantity.setQuantity(remainingQty);
			
			response.put("msg", orders);
		}else{
			response.put("msg", "less stock");
		}
		
		return response;
	}

}
