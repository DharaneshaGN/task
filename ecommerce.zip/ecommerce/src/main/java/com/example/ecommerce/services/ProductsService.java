package com.example.ecommerce.services;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ecommerce.model.Products;
import com.example.ecommerce.repository.ProductsRepo;

@Service
public class ProductsService {
	
	@Autowired
	private ProductsRepo productsRepo;

	public Map<String, Object> ProductQty(String pid, int qty) {
		Map<String, Object> response = new HashMap<String, Object>();
		Products quantity=productsRepo.findByProductId(pid);
		if(quantity.getQuantity()>=qty){
			response.put("msg", "you can buy");
		}else{
			response.put("msg", "less stock ");
		}
		
		return response;
	}
	
	

}
