package com.example.ecommerce.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.example.ecommerce.utils.CascadeSave;

import lombok.Data;

@Document
@Data
public class Orders {
	
	@Id
	private String OrderId;
	private String caId;//customer account Id
	@CascadeSave
	private OrderProducts orderProducts;
	@CascadeSave
	private PaymentDetails paymentDetails;
	
	
	

}
