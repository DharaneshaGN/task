package com.example.ecommerce.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.example.ecommerce.utils.CascadeSave;

import lombok.Data;

@Document
@Data
public class Products {

	@Id
	private String productId;
	
	private String cid;//categoryId
	private String productName;
	private String productDisc;//description
	private int Quantity;
	private double mrp;
	private double disount;//in percentage
	private double sellingPrices;
	@CascadeSave
	private MaufactureDetails maufactureDetails;
	
	
	
}
